
DOOM Enemies - v2 notstretched
==============================

This dataset was exported via roboflow.ai on March 10, 2022 at 8:08 AM GMT

It includes 100 images.
Enemies are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


